mu=0;
sigma=1;

x=-5:0.1:5;
y=1./sqrt(2*pi*sigma.^2)*exp(-0.5.*(x-mu).^2/sigma.^2);
plot(x,y)